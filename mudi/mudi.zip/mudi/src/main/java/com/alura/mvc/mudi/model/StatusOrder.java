package com.alura.mvc.mudi.model;

public enum StatusOrder {
	WAITING, APPROVED, DELIVERED;

}
